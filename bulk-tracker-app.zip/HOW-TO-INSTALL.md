# Bulk Tracker — get it on your phone

You'll host these files for free, then add the site to your iPhone home screen so it
behaves like a real app (own icon, full screen, works offline, data saved on the phone).

## Step 1 — Host it (pick ONE)

### Option A: Netlify Drop (easiest, ~2 min, no account needed to start)
1. Go to https://app.netlify.com/drop
2. Drag the **whole `bulk-tracker-app` folder** onto the page (unzip first if needed).
3. Netlify gives you a URL like `https://random-name-123.netlify.app`.
4. (Optional) Make a free account to keep the site and rename it to something like
   `conner-bulk.netlify.app`.

### Option B: GitHub Pages (free, permanent, a little more setup)
1. Create a free GitHub account, make a new repo.
2. Upload the 6 files (index.html, manifest.webmanifest, sw.js, and the 3 icons).
3. Repo → Settings → Pages → Source: `main` branch → Save.
4. Your URL will be `https://YOURNAME.github.io/REPO/`.

## Step 2 — Add to your iPhone home screen
1. Open the URL in **Safari** (must be Safari on iOS, not Chrome).
2. Tap the **Share** button (square with an up-arrow).
3. Scroll down → **Add to Home Screen** → Add.
4. The blue dumbbell icon appears on your home screen. Open it — it runs full screen.

Android: open the URL in Chrome → menu (⋮) → **Install app / Add to Home screen**.

## Updating later
When Conner sends you a new version, replace the files at the same URL:
- Netlify: drag the updated folder onto https://app.netlify.com/drop (or your site's
  Deploys tab). Same URL, so your home-screen icon keeps working.
- GitHub: replace the files in the repo.
Then open the app and pull-to-refresh once. The service worker is versioned, so the
new version loads and **your logged data stays intact** (it's tied to the URL).

## Notes
- Your data (weights, food log, profile) lives only on that phone/browser.
- Keep the same URL and don't clear the site's data, and your history persists.
